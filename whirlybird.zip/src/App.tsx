/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Trophy, Play, RotateCcw, ArrowLeft, ArrowRight } from 'lucide-react';

// Constants
const CANVAS_WIDTH = 400;
const CANVAS_HEIGHT = 600;
const GRAVITY = 0.4;
const JUMP_STRENGTH = -12;
const PLATFORM_WIDTH = 60;
const PLATFORM_HEIGHT = 15;
const PLAYER_SIZE = 30;
const INITIAL_PLATFORM_COUNT = 8;

interface Platform {
  x: number;
  y: number;
  type: 'normal' | 'moving' | 'breakable' | 'spring';
  direction?: number;
  broken?: boolean;
}

interface Player {
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<'START' | 'PLAYING' | 'GAMEOVER'>('START');
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  
  // Game state refs to avoid closure issues in the loop
  const playerRef = useRef<Player>({
    x: CANVAS_WIDTH / 2 - PLAYER_SIZE / 2,
    y: CANVAS_HEIGHT - 100,
    vx: 0,
    vy: 0,
    width: PLAYER_SIZE,
    height: PLAYER_SIZE
  });
  
  const platformsRef = useRef<Platform[]>([]);
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const requestRef = useRef<number>(null);
  const cameraYRef = useRef(0);

  useEffect(() => {
    const savedHighScore = localStorage.getItem('whirlybird-highscore');
    if (savedHighScore) setHighScore(parseInt(savedHighScore));

    const handleKeyDown = (e: KeyboardEvent) => { keysRef.current[e.code] = true; };
    const handleKeyUp = (e: KeyboardEvent) => { keysRef.current[e.code] = false; };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, []);

  const initGame = () => {
    playerRef.current = {
      x: CANVAS_WIDTH / 2 - PLAYER_SIZE / 2,
      y: CANVAS_HEIGHT - 100,
      vx: 0,
      vy: 0,
      width: PLAYER_SIZE,
      height: PLAYER_SIZE
    };
    
    cameraYRef.current = 0;
    setScore(0);
    
    // Initial platforms
    const platforms: Platform[] = [];
    // Base platform
    platforms.push({ x: CANVAS_WIDTH / 2 - PLATFORM_WIDTH / 2, y: CANVAS_HEIGHT - 50, type: 'normal' });
    
    for (let i = 1; i < INITIAL_PLATFORM_COUNT; i++) {
      platforms.push(generatePlatform(CANVAS_HEIGHT - (i * (CANVAS_HEIGHT / INITIAL_PLATFORM_COUNT))));
    }
    platformsRef.current = platforms;
    
    setGameState('PLAYING');
    requestRef.current = requestAnimationFrame(gameLoop);
  };

  const generatePlatform = (y: number): Platform => {
    const typeRand = Math.random();
    let type: Platform['type'] = 'normal';
    if (y < -1000) {
      if (typeRand > 0.8) type = 'moving';
      else if (typeRand > 0.7) type = 'breakable';
      else if (typeRand > 0.6) type = 'spring';
    } else if (y < -500) {
      if (typeRand > 0.9) type = 'moving';
      else if (typeRand > 0.8) type = 'spring';
    }

    return {
      x: Math.random() * (CANVAS_WIDTH - PLATFORM_WIDTH),
      y: y,
      type: type,
      direction: Math.random() > 0.5 ? 1 : -1
    };
  };

  const gameLoop = () => {
    if (gameState === 'GAMEOVER') return;

    update();
    draw();
    
    requestRef.current = requestAnimationFrame(gameLoop);
  };

  const update = () => {
    const player = playerRef.current;
    const platforms = platformsRef.current;

    // Movement
    if (keysRef.current['ArrowLeft']) player.vx -= 0.8;
    if (keysRef.current['ArrowRight']) player.vx += 0.8;
    player.vx *= 0.9; // Friction
    player.x += player.vx;

    // Screen wrap
    if (player.x + player.width < 0) player.x = CANVAS_WIDTH;
    if (player.x > CANVAS_WIDTH) player.x = -player.width;

    // Physics
    player.vy += GRAVITY;
    player.y += player.vy;

    // Camera follow
    if (player.y < cameraYRef.current + CANVAS_HEIGHT / 2) {
      const diff = (cameraYRef.current + CANVAS_HEIGHT / 2) - player.y;
      cameraYRef.current -= diff;
      setScore(prev => Math.max(prev, Math.floor(-cameraYRef.current / 10)));
    }

    // Platform collision (only when falling)
    if (player.vy > 0) {
      for (const plat of platforms) {
        if (!plat.broken &&
            player.x + player.width > plat.x &&
            player.x < plat.x + PLATFORM_WIDTH &&
            player.y + player.height > plat.y &&
            player.y + player.height < plat.y + PLATFORM_HEIGHT + player.vy) {
          
          if (plat.type === 'breakable') {
            plat.broken = true;
          } else if (plat.type === 'spring') {
            player.vy = JUMP_STRENGTH * 2;
          } else {
            player.vy = JUMP_STRENGTH;
          }
          break;
        }
      }
    }

    // Update moving platforms
    for (const plat of platforms) {
      if (plat.type === 'moving') {
        plat.x += (plat.direction || 1) * 2;
        if (plat.x <= 0 || plat.x >= CANVAS_WIDTH - PLATFORM_WIDTH) {
          plat.direction = -(plat.direction || 1);
        }
      }
    }

    // Recycle platforms
    const lowestPlatformY = Math.max(...platforms.map(p => p.y));
    if (lowestPlatformY > cameraYRef.current + CANVAS_HEIGHT) {
      platformsRef.current = platforms.filter(p => p.y <= cameraYRef.current + CANVAS_HEIGHT);
      const highestPlatformY = Math.min(...platformsRef.current.map(p => p.y));
      platformsRef.current.push(generatePlatform(highestPlatformY - (CANVAS_HEIGHT / INITIAL_PLATFORM_COUNT)));
    }

    // Game Over
    if (player.y > cameraYRef.current + CANVAS_HEIGHT) {
      setGameState('GAMEOVER');
      setHighScore(prev => {
        const newScore = Math.max(prev, Math.floor(-cameraYRef.current / 10));
        localStorage.setItem('whirlybird-highscore', newScore.toString());
        return newScore;
      });
    }
  };

  const draw = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear
    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Background (Grid)
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.05)';
    ctx.lineWidth = 1;
    for (let x = 0; x < CANVAS_WIDTH; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, CANVAS_HEIGHT);
      ctx.stroke();
    }
    for (let y = -cameraYRef.current % 40; y < CANVAS_HEIGHT; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(CANVAS_WIDTH, y);
      ctx.stroke();
    }

    // Platforms
    for (const plat of platformsRef.current) {
      if (plat.broken) continue;
      
      const drawY = plat.y - cameraYRef.current;
      if (drawY < -50 || drawY > CANVAS_HEIGHT + 50) continue;

      ctx.fillStyle = plat.type === 'moving' ? '#3B82F6' : 
                      plat.type === 'breakable' ? '#EF4444' : 
                      plat.type === 'spring' ? '#F59E0B' : '#10B981';
      
      // Platform body
      ctx.beginPath();
      ctx.roundRect(plat.x, drawY, PLATFORM_WIDTH, PLATFORM_HEIGHT, 5);
      ctx.fill();
      
      // Platform detail
      ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.fillRect(plat.x + 5, drawY + 3, PLATFORM_WIDTH - 10, 3);
    }

    // Player
    const player = playerRef.current;
    const playerDrawY = player.y - cameraYRef.current;
    
    ctx.save();
    ctx.translate(player.x + player.width / 2, playerDrawY + player.height / 2);
    
    // Tilt based on velocity
    ctx.rotate(player.vx * 0.05);

    // Body
    ctx.fillStyle = '#F43F5E';
    ctx.beginPath();
    ctx.roundRect(-player.width / 2, -player.height / 2, player.width, player.height, 8);
    ctx.fill();

    // Eyes
    ctx.fillStyle = 'white';
    ctx.beginPath();
    ctx.arc(-6, -4, 4, 0, Math.PI * 2);
    ctx.arc(6, -4, 4, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.fillStyle = 'black';
    ctx.beginPath();
    ctx.arc(-6 + (player.vx * 0.2), -4, 2, 0, Math.PI * 2);
    ctx.arc(6 + (player.vx * 0.2), -4, 2, 0, Math.PI * 2);
    ctx.fill();

    // Propeller (if jumping high or just for flavor)
    if (player.vy < 0) {
      ctx.strokeStyle = '#333';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, -player.height / 2);
      ctx.lineTo(0, -player.height / 2 - 10);
      ctx.stroke();
      
      const propWidth = 20;
      const time = Date.now() * 0.02;
      ctx.beginPath();
      ctx.ellipse(0, -player.height / 2 - 10, Math.abs(propWidth * Math.sin(time)), 4, 0, 0, Math.PI * 2);
      ctx.fillStyle = '#666';
      ctx.fill();
    }

    ctx.restore();
  };

  return (
    <div className="min-h-screen bg-[#FDFCF0] flex flex-col items-center justify-center p-4 font-sans text-slate-900">
      <div className="relative w-full max-w-[400px] aspect-[2/3] bg-white rounded-3xl shadow-2xl overflow-hidden border-8 border-slate-100">
        
        {/* Game Canvas */}
        <canvas
          ref={canvasRef}
          width={CANVAS_WIDTH}
          height={CANVAS_HEIGHT}
          className="w-full h-full block"
        />

        {/* HUD */}
        {gameState === 'PLAYING' && (
          <div className="absolute top-6 left-6 right-6 flex justify-between items-start pointer-events-none">
            <div className="bg-white/80 backdrop-blur-sm px-4 py-2 rounded-2xl shadow-sm border border-slate-100">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Score</p>
              <p className="text-2xl font-black text-slate-800">{score}</p>
            </div>
            <div className="bg-white/80 backdrop-blur-sm px-4 py-2 rounded-2xl shadow-sm border border-slate-100 text-right">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Best</p>
              <p className="text-xl font-black text-slate-800">{highScore}</p>
            </div>
          </div>
        )}

        {/* Overlay Screens */}
        <AnimatePresence>
          {gameState === 'START' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-white/90 backdrop-blur-md flex flex-col items-center justify-center p-8 text-center"
            >
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                className="w-24 h-24 bg-rose-500 rounded-2xl mb-6 shadow-xl flex items-center justify-center"
              >
                <div className="relative">
                  <div className="flex gap-2 mb-1">
                    <div className="w-4 h-4 bg-white rounded-full" />
                    <div className="w-4 h-4 bg-white rounded-full" />
                  </div>
                  <div className="w-10 h-2 bg-white/30 rounded-full mx-auto" />
                </div>
              </motion.div>
              
              <h1 className="text-4xl font-black tracking-tighter mb-2 text-slate-900">WHIRLYBIRD</h1>
              <p className="text-slate-500 mb-8 max-w-[240px]">Jump as high as you can! Use arrow keys to move.</p>
              
              <button
                onClick={initGame}
                className="group relative bg-emerald-500 hover:bg-emerald-600 text-white px-8 py-4 rounded-2xl font-bold text-xl transition-all hover:scale-105 active:scale-95 shadow-lg shadow-emerald-200 flex items-center gap-3"
              >
                <Play className="w-6 h-6 fill-current" />
                START GAME
              </button>

              <div className="mt-12 flex gap-4 text-slate-400">
                <div className="flex items-center gap-2 bg-slate-50 px-3 py-2 rounded-xl border border-slate-100">
                  <ArrowLeft className="w-4 h-4" />
                  <ArrowRight className="w-4 h-4" />
                  <span className="text-xs font-bold">MOVE</span>
                </div>
              </div>
            </motion.div>
          )}

          {gameState === 'GAMEOVER' && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm flex flex-col items-center justify-center p-8 text-center text-white"
            >
              <div className="bg-white text-slate-900 p-8 rounded-[2.5rem] shadow-2xl w-full max-w-[300px]">
                <Trophy className="w-16 h-16 text-amber-400 mx-auto mb-4" />
                <h2 className="text-3xl font-black tracking-tighter mb-1">GAME OVER</h2>
                <p className="text-slate-400 font-bold text-sm uppercase tracking-widest mb-6">You reached</p>
                
                <div className="flex flex-col gap-1 mb-8">
                  <span className="text-6xl font-black text-slate-900 leading-none">{score}</span>
                  <span className="text-xs font-bold text-slate-400 uppercase">Points</span>
                </div>

                <div className="bg-slate-50 rounded-2xl p-4 mb-8 flex justify-between items-center">
                  <span className="text-xs font-bold text-slate-400 uppercase">Best Score</span>
                  <span className="text-xl font-black text-slate-800">{highScore}</span>
                </div>

                <button
                  onClick={initGame}
                  className="w-full bg-rose-500 hover:bg-rose-600 text-white py-4 rounded-2xl font-bold text-lg transition-all hover:scale-105 active:scale-95 shadow-lg shadow-rose-200 flex items-center justify-center gap-2"
                >
                  <RotateCcw className="w-5 h-5" />
                  TRY AGAIN
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <p className="mt-8 text-slate-400 text-sm font-medium">
        Built with React & Canvas • Inspired by Whirlybird
      </p>
    </div>
  );
}
